#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include "halfprec_float.h"

// Generate a random floating number with no limitation
static float random_float( void );

// Generate a random uint8 number
static uint8_t random_uint8( void );

// Generate random float array of specified shape
float*
generate_random_float_array( uint32_t *shape, uint8_t dim )
{
    assert( shape != 0 && dim != 0 );

    uint32_t i;
    uint32_t num_elem = 1;
    float *ret;

    for ( i = 0; i < dim; i++ ) {
        assert( shape[i] != 0 );
        num_elem *= shape[i];
    }
    ret = (float * ) malloc( sizeof( float ) * num_elem ); 
    for ( i = 0; i < num_elem; i++ )
        ret[i] = random_float( );

    return ret;
}

// Generate random uint8_array of specified shape
uint8_t *
generate_random_uint8_array( uint32_t *shape, uint8_t dim )
{
    assert( shape != 0 && dim != 0 );
    uint32_t i, num_elem = 1;
    uint8_t *ret;

    for ( i = 0; i < dim; i++ ) {
        assert( shape[i] != 0 );
        num_elem *= shape[i];
    }

    ret = (uint8_t *) malloc( sizeof( uint8_t )*num_elem );
    for ( i = 0; i < num_elem; i++ )
        ret[i] = random_uint8( );

    return ret;
}

// ------------------------------------------------------ //
//  Implementation of static functions                    //
// ------------------------------------------------------ //
float
random_float( void )
{
    float f1, f2;

    do {
        f2 = (float) random( );
    } while( f2 == 0 );

    f1 = ( float )random( );

    return f1/f2;
}

uint8_t
random_uint8( void )
{
    return ( uint8_t ) (random( ) % 256);
}

// ------------------------------------------------------ //
//  Routines for single layer                             //
// ------------------------------------------------------ //
void
generate_input_mlp_9216x1024( void )
{
    uint32_t i, j, k, block_i, block_j, block_width, block_height;
    uint32_t input_shape[1] = { 9216 };
    uint32_t weight_shape[2] = { 9216, 1024 };
    float *sp_weight, *sp_input;
    float16_t hp_val;

    // Input array, original
    sp_input = generate_random_float_array( input_shape, 1 );
    const char *file_name = "input_mlp_9216x1024.orig";
    FILE *fp = fopen( file_name, "w" );
    fprintf( stdout, "writing original weight into %s...\n", file_name );
    for ( i = 0; i < 9216; i++ ) {
        fprintf( fp, "%-8.4f ", sp_input[i] );
        if ( i % 128 == 127 ) fprintf( fp, "\n" );
    }
    fclose( fp );

    // Weight, original
    float *weight = generate_random_float_array( weight_shape, 2 );
    file_name = "weight_mlp_9216x1024.orig";
    fprintf( stdout, "Writing original weight into %s...\n", file_name );
    fp = fopen( file_name, "w" );
    for ( i = 0; i < 9216; i++ ) {
        for ( j = 0; j < 1024; j++ )
            fprintf( fp, "%-8.4f ", weight[i * 1024+ j] );
        fprintf( fp, "\n" );
    }
    fclose( fp );

    // 3. Adaped input
    file_name = "mlp_9216x1024.h";
    fprintf( stdout, "adapted input is written into %s...\n", file_name );

    fp = fopen( file_name, "w" );
    //  3.1 Input array
    fprintf( fp, "// Generated data for MLP 9216x1024\n\n" );
    fprintf( fp, "// Input\n" );
    fprintf( fp, "input = ["  );
    for ( i = 0; i < 9216; i++ ) {
        if ( i % 1024 == 0 ) fprintf( fp, "\n    " );
        hp_val = float_to_half( sp_input[i] );
        fprintf( fp, "0x%04X", hp_val );
        if ( i != 9215 ) fprintf( fp, ", " ); 
    }
    fprintf( fp, " ];\n" );

    // 3.2 Weight
    block_width = 128; 
    block_height = 256;
    uint32_t num_printed = 0;
    fprintf( fp, "weight = [" );
    for ( block_i = 0; block_i < 1024/block_width; block_i++ ) {
        for ( block_j = 0; block_j < 9216/block_height; block_j++ ) {
            for ( k = 0; k < 16; k++ ) { // tile iterator
                for ( j = block_j * block_height + k; j < (block_j + 1) * block_height; j += 16 ) {
                    for ( i = block_i * block_width; i < (block_i + 1) * block_width; i++ ) {
                        hp_val = float_to_half( weight[ j*1024 + i ] );
                        fprintf( fp, "0x%04X", hp_val );
                        if ( ++num_printed < (9216 * 1024) )
                            fprintf( fp, ", " );
                    }
                }
            } 
        }
        fprintf( fp, "\n" );
    }
    fprintf( fp, "\b\b ];\n" );
    fclose( fp );
}

int 
main( void )
{
    generate_input_mlp_9216x1024( );
    return 0;
}

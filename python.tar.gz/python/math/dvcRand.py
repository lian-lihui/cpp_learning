
import numpy
def dvcRand_Gaussion( shape, mu, sigma ):
    return numpy.random.normal( mu, sigma, shape )



import numpy
def dvc_rand_gaussian( mu, sigma, shape ):
    return numpy.random.normal( mu, sigma, shape )



import dvcRand
import dvcUtil
import dvcFormat
import sys
import math
import numpy

def genData_test( shape, random = True, format = "NC1HWC0" ):
    """ Generate data of NC1HWC0 format """
    if len( shape ) != 4:
        sys.stderr.writed( "[ERROR]: shape shoud be of length 4, but get %d!\n" % len( shape ) )
        sys.exit( 1 )
    
    if random:
        ret = dvcRand.dvcRand_Gaussion(shape, mu = 1.0, sigma = 3)
    else:
        ret = numpy.ones( shape, dtype=numpy.float16 )

    formatedData = dvcFormat.formatData_QuantizeChannel( ret )
    dvcUtil.dumpData( ret, "orig", fileFmt="txt",  outDir="output" )
    dvcUtil.dumpData( formatedData, "formated", fileFmt="txt", outDir="output" )

def genData_testWeight( ):
    shape = ( 1, 65, 11, 11, 3 )
    origWeight = dvcRand.dvcRand_Gaussion(shape, mu=1.0, sigma=3)
    formatedWeight = dvcFormat.formatData_ReformConvWeight( origWeight, 128, 16 ) 
    dvcUtil.dumpData( origWeight, "orig", fileFmt="txt", outDir="output" )
    dvcUtil.dumpData( formatedWeight, "formated", fileFmt="txt", outDir="output" )

if __name__ == "__main__":
    genData_test( (1, 45, 13, 34) )
    genData_testWeight( )

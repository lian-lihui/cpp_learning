
import dvcRand
import sys
import math
import numpy
def dvc_gen_data( shape, random = True, format = "NC1HWC0" ):
    """ Generate data of NC1HWC0 format """
    if len( shape ) != 4:
        sys.stderr.writed( "[ERROR]: shape shoud be of length 4, but get %d!\n" % len( shape ) )
        sys.exit( 1 )

    channel = shape[1]
    if numpy.mod( channel, 16 ) != 0:
        sys.stderr.write( "[INFO]: channel=%d padding to multiple of 16.\n" % channel )
        shape[1] = int( math.ceil( float( shape[1] )/16 )*16 )
        sys.stderr.write( "[INFO]: After padding channel=%d \n" % shape[1] )
    
    if random:
        ret = dvcRand.dvc_rand_gaussian( mu = 1.0, sigma = 3, shape = shape )
    else:
        ret = numpy.ones( shape, dtype=numpy.float16 )

    dvc_ret = ret.copy( )
    sys.stdout.write( "[INFO]: before reshape: %s\n" % shape )
    new_shape = ( shape[0], int(shape[1]/16), 16, shape[2], shape[3] )
    dvc_ret.reshape( new_shape )
    sys.stdout.write( "[INFO]: After reshape: %s\n" % str( new_shape ) )
    if dvc_ret.shape != ret.shape:
        dvc_ret = dvc_ret.transpose( (0, 1, 3, 4, 2) )
    else:
        dvc_ret = dvc_ret.transpose( (0, 2, 3, 1) )
    return ret, dvc_ret


def dvc_dump_data( data, file_name = "test", format="txt" ): 
    """Dump data to file"""
    sys.stdout.write( "[INFO]: Dumping data to '%s.%s'...\n" %( file_name, format ) )
    foutput = open( "%s.%s" % ( file_name, format ), "w" )
    if not foutput:
        sys.stderr.write( "[ERROR]: Failed to open '%s.%s'\n" % ( file_name, format ) )
        sys.exit( 1 )

    foutput.write( "#shape: %s\n" %  str( data.shape ) )
    for val in numpy.nditer( data, order = 'C' ):
        foutput.write( "%f\n" % val )

    sys.stdout.write( "[INFO]: Dumping data to '%s.%s'...Done!\n" %( file_name, format ) )


def test( ):
    data, dvc_data = dvc_gen_data( [1, 3, 4, 5] ) 
    dvc_dump_data( data )
    dvc_dump_data( dvc_data, "dvc_test" )

if __name__ == "__main__":
    test( )

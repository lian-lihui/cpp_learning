
import numpy as NP
import sys
import math

# ----------------------------------------------------------------------------------------------
def formatData_CeilDiv( int1, int2 ):
    """ Return ceil divison of two integers"""
    return int( math.ceil( float(int1)/int2 ) )
    
# ----------------------------------------------------------------------------------------------
def formatData_PaddToMultiple( inputData, padSpec ):
    """Padding some dimention(s) to multiple of value specified by padSpec"""
    if len( inputData.shape ) != len( padSpec ):  
        sys.stderr.write( "[ERROR]: inputData and padSpec does not match!\n " );
        sys.stderr.write( "         inputData.shape=%s padSpec=%s\n" %
                          (str(inputData.shape), str(padSpec)))
        sys.exit( 1 )

    padConfig = []
    dimIdx = 0
    for spec in padSpec:
        if spec <= 1:
            padConfig.append( (0, 0) )
        else:
            paddLength = formatData_CeilDiv( inputData.shape[dimIdx], spec )*spec
            paddLength -= inputData.shape[dimIdx]
            padConfig.append( (0, paddLength) )
        dimIdx += 1
    return NP.pad( inputData, padConfig, 'constant' )

# ---------------------------------------------------------------------------------------------
def formatData_ReformConvWeight( weightOrig, fractalSize, uMultSize ):
    """ Generate formated weight data"""
    sys.stdout.write( "[INFO]: Reforming convolution weight...\n" );

    legalFractal = ( 16, 32, 64, 128 )
    if ( len(weightOrig.shape) != 5 ):
        sys.stderr.write( "[ERROR]: Weight data shold be 5-dimentional!\n" )
        sys.exit( 1 )
    if fractalSize not in legalFractal:
        sys.stderr.write( "[ERROR]: Invalid fractalsize: %d\n", fractalsize )
        sys.stderr.exit( 1 )


    sys.stdout.write( "[INFO]: Original input shape=%s\n" % str( weightOrig.shape ) )
    # 1. process channel dimention:
    #    i)  padding channel dimention to multiple of 16
    #    ii) Move C1 before H 
    formatedWeight = formatData_PaddToMultiple( weightOrig, (1, 1, 1, 1, 16) ) 
    (batch, num, height, width, channel) = formatedWeight.shape
    formatedWeight = NP.reshape( formatedWeight, 
            (batch, num, height, width, formatData_CeilDiv(width, 16), 16 ))
    formatedWeight = NP.transpose( formatedWeight, (0, 1, 5, 2, 3, 4) ) 
    formatedWeight = NP.reshape( formatedWeight, ( batch, num, -1) ) 
    sys.stdout.write( "[INFO]: After processing channel dimention: shape=%s\n"
            % str(formatedWeight.shape) )

    # 2. Process fractal re-organization 
    formatedWeight = formatData_PaddToMultiple( formatedWeight, ( 1, fractalSize, fractalSize ) )
    (batch, num, conv_data) = formatedWeight.shape
    fracN1 = formatData_CeilDiv( num, fractalSize ) 
    fracM1 = formatData_CeilDiv( conv_data, fractalSize )
    newShape = ( batch, fracN1, fractalSize, fracM1, fractalSize )
    formatedWeight = NP.reshape( formatedWeight, newShape )
    formatedWeight = NP.transpose( formatedWeight, (0, 3, 1, 2, 4) )
    sys.stdout.write( "[INFO]: After fractal reorganization: shape=%s\n" %
            str(formatedWeight.shape) )

    # 3. Process u-arch multiplier re-organization
    formatedWeight = formatData_PaddToMultiple( formatedWeight, (1, 1, 1, 16, 16) )
    (batch, fracM1, fractN1, N1, M1) = formatedWeight.shape
    uarchN = formatData_CeilDiv( N1, 16 )
    uarchM = formatData_CeilDiv( M1, 16 )
    newShape = ( batch, fracM1, fractN1, uarchN, 16, uarchM, 16 )
    formatedWeight = NP.reshape( formatedWeight, newShape )
    formatedWeight = NP.transpose( formatedWeight, (0, 1, 2, 5, 3, 4, 6) )
    sys.stdout.write( "[INFO]: After adapting to u-arch mutiplier: shape=%s\n" %
            str(formatedWeight.shape) )

    sys.stdout.write( "[INFO]: Reforming convolution weight...Done\n" );
    return formatedWeight

    
# ---------------------------------------------------------------------------------------------
def formatData_QuantizeChannel( inputData ):
    """ Reformat inputData of NHWC format to NC1HWC0 format""" 
    sys.stdout.write( "[INFO]: Quantizing channel dimention...\n" );

    if len( inputData.shape ) != 4:
        sys.stderr.write( "[ERROR]: Input data should be 4 dimentional!\n" );
        sys.exit( 1 )

    sys.stdout.write( "[INFO]: Original data shape=%s\n" % str(inputData.shape) )

    formatedInput = formatData_PaddToMultiple( inputData, (1, 16, 1, 1) )
    (num, channel, height, width) = formatedInput.shape
    newShape = (num, formatData_CeilDiv( width, 16 ), 16, height, width ) 
    formatedInput = NP.reshape( formatedInput, newShape )
    formatedInput = NP.transpose(formatedInput, (0, 1, 3, 4, 2))

    sys.stdout.write( "[INFO]: Quantized data shape=%s\n" % str(formatedInput.shape) )
    sys.stdout.write( "[INFO]: Quantizing channel dimention...Done!\n\n" );
    return formatedInput



import numpy
import sys

def dumpData( data, fileName, fileFmt="txt", dataFmt="fp32", outDir="." ):
    """Dump data to file"""
    validFmt = ( "txt", "bin" )
    if fileFmt not in validFmt:
        sys.stderr.write( "[ERROR]: Invalid fileFmt( %s )!\n" % fileFmt )
        sys.stderr.write( "[INFO]:  Valid choices are %s !\n" % validFmt )
        sys.exit( 1 )

    if fileFmt == "bin":
        fileFmt = "data"
    pathName = ("%s/%s.%s" % (outDir, fileName, fileFmt ))
    sys.stdout.write( "[INFO]: Dumping data to '%s'...\n" % pathName )

    foutput = open( pathName, "w" )
    if not foutput:
        sys.stderr.write( "[ERROR]: Failed to open '%s'!\n" % pathName )
        sys.exit( 1 )

    foutput.write( "#shape: %s\n" %  str( data.shape ) )
    for val in numpy.nditer( data, order = 'C' ):
        foutput.write( "%f\n" % val )

    sys.stdout.write( "[INFO]: Dumping data to '%s'...Done!\n\n" %(pathName) )


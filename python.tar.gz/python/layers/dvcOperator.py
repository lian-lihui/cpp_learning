
import math
import numpy
def dvc_pooling( input_data, pad_l, pad_r, pad_top, pad_bot, win_h, win_w,
        stride_l, stride_r, type = "max" ):
    """Input is of data format NCHW"""
    input_h, input_w = input_data.shape[2], input_data.shape[3]
    rslt_h = math.ceil( (float( input_h ) + pad_top + pad_bot - win_h)/stride_h ) + 1
    rslt_w = math.ceil( (float( input_w ) + pad_l + pad_r - win_w )/stride_w ) + 1
    rslt_h = int( rslt_h )
    rslt_w = int( rlst_w )

    input_data_cpy = input_data.copy( )
    numpy.pad( input_data_cpy, ( (0, 0), (0, 0), (pad_top, pad_bot), (pad_l, pad_r) ), 
               'constant' )
    ret = numpy.zeros( (input_data.shape[0], 
                        input_data.shape[1],
                        rslt_h, rslt_w ) )

    for iter_c in range( input_data.shape[1] ):
        for i in range( rslt_h ):
            win_pos_i = i*stride_h
            for j in range( rslt_h ):
                win_pos_j = j*stride_w
                ret[0, iter_c, i, j] = input_data_cpy[0, iter_c, win_pos_i, win_pos_j]

                # process the sub window
                for ii in range( win_pos_i, 1, min( win_pos_i + win_h, input_data_cpy.shape[2] ):  
                    for jj in range( win_pos_j, 1, min( win_pos_j + win_w, input_data_cpy.shape[3] ):
                        ret[0, iter_c, i, j] = max( ret[0, iter_c, i, j], ret[0, iter_c, ii, jj] )

    return ret;

